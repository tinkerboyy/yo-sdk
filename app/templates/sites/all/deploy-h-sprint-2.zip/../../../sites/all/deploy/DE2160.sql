UPDATE `dbSolutionMatrix`.`tbAvailableToOptions` SET `orderBy` = '18' WHERE `tbAvailableToOptions`.`name` ='NASA';
UPDATE `dbSolutionMatrix`.`tbAvailableToOptions` SET `orderBy` = '19' WHERE `tbAvailableToOptions`.`name` = 'USDA'
