ALTER TABLE `hallways`.`user_preferences` ADD COLUMN data MEDIUMTEXT NULL;
