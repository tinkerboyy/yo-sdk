ALTER TABLE `hallways`.`gateway_project_entity_reference` ADD COLUMN data MEDIUMTEXT;
