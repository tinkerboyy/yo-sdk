DELETE
FROM field_data_field_contract_format
WHERE field_contract_format_value	= 'FSS or GWAC';
