UPDATE `dbSolutionMatrix`.`tbAvailableToOptions` SET `name` = 'Dept of Defense'
WHERE `tbAvailableToOptions`.`orderBy` =1;

UPDATE `dbSolutionMatrix`.`tbAvailableToOptions` SET `name` = 'Federal Agencies'
WHERE `tbAvailableToOptions`.`orderBy` =6;

UPDATE `dbSolutionMatrix`.`tbAvailableToOptions`
SET `orderBy` = '21' WHERE `tbAvailableToOptions`.`name` ='Other Civilian Agency';

UPDATE `dbSolutionMatrix`.`tbAvailableToOptions`
SET `name` ='Other Federal Agency' WHERE `tbAvailableToOptions`.`orderBy` = '21';

INSERT INTO `dbSolutionMatrix`.`tbOrganizations` (`pkOrganizationId`, `fkParentOrganizationId`, `name`, `shortName`)
VALUES (NULL, NULL, 'National Science Foundation', 'NSF');

INSERT INTO `dbSolutionMatrix`.`tbOrganizations` (`pkOrganizationId`, `fkParentOrganizationId`, `name`, `shortName`)
VALUES (NULL, NULL, 'Office of Personnel Mgmt', 'OPM');

UPDATE `dbSolutionMatrix`.`tbOrganizations` SET `name` = 'Veteran''s Affairs'
WHERE `tbOrganizations`.`shortName` ='VA';

UPDATE `dbSolutionMatrix`.`tbAvailableToOptions`
SET `orderBy` = '19' WHERE `tbAvailableToOptions`.`name` ='USDA';

UPDATE `dbSolutionMatrix`.`tbAvailableToOptions`
SET `orderBy` = '20' WHERE `tbAvailableToOptions`.`name` ='VA';

INSERT INTO `dbSolutionMatrix`.`tbAvailableToOptions` (`pkOptionId`, `name`, `fkOptionParentId`, `adminOnly`, `orderBy`)
VALUES (NULL, 'NASA', '6', NULL, '18');
