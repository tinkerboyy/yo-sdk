CREATE TABLE `hallways`.`tmp_gateway_project_entity_reference` LIKE `hallways`.`gateway_project_entity_reference`;
INSERT `hallways`.`tmp_gateway_project_entity_reference` SELECT * FROM `hallways`.`gateway_project_entity_reference` WHERE 1 GROUP BY uid, pid, entity_id;
ALTER TABLE `hallways`.`tmp_gateway_project_entity_reference` DROP COLUMN id;
ALTER TABLE `hallways`.`tmp_gateway_project_entity_reference` ADD id INT PRIMARY KEY AUTO_INCREMENT FIRST;
DROP TABLE `hallways`.`gateway_project_entity_reference`;
RENAME TABLE `hallways`.`tmp_gateway_project_entity_reference` TO `hallways`.`gateway_project_entity_reference`;
ALTER TABLE `hallways`.`gateway_project_entity_reference` ADD UNIQUE KEY `project_entity` (`pid`, `entity_id`);
