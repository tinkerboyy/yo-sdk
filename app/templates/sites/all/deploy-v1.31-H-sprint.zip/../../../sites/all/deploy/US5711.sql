ALTER TABLE `dbSolutionMatrix`.`tbContractSolutions` ADD `pricesPaidUrl` TEXT NOT NULL ;
