CREATE TABLE IF NOT EXISTS `ag_votes` (
  `id` int(14) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `type` varchar(20) NOT NULL,
  `itemId` int(14) NOT NULL,
  `uid` int(11) NOT NULL,
  `vote` int(14) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
