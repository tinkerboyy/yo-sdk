CREATE TABLE `dbSolutionMatrix`.`tbUserAgencyPreferences` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `fkOptionId` int(11) unsigned NOT NULL,
  `user_agency` varchar(80) NOT NULL DEFAULT '',
  `count` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
