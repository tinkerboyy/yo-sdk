DROP TABLE IF EXISTS `dbSolutionMatrix`.`tbDataIssues`;
CREATE TABLE IF NOT EXISTS `dbSolutionMatrix`.`tbDataIssues` (
  `id` int(14) unsigned NOT NULL AUTO_INCREMENT,
  `fkSolutionId` int(14) NOT NULL,
  `userEmail` varchar(255) NOT NULL,
  `comments` mediumtext NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `resolved` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;
