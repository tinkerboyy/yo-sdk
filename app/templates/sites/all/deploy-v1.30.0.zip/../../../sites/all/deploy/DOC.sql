insert into `dbSolutionMatrix`.tbOrganizations(name, shortName) values ('Dept of Commerce', 'DOC');
