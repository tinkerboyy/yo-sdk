ALTER TABLE `dbSolutionMatrix`.`tbSolutionTypes` 
ADD type TEXT;

UPDATE `dbSolutionMatrix`.`tbSolutionTypes` 
SET Type = "Contract" 
WHERE shortName IN ('IDIQ', 'MAS', 'GWAC', 'BPA', 'NSN', 'MS', 'ELA', 'Tender', 'IAA');

UPDATE `dbSolutionMatrix`.`tbSolutionTypes` 
SET Type = "Program" 
WHERE shortName IN ('FSSI', 'SSO');

INSERT INTO `dbSolutionMatrix`.`tbSolutionTypes` (name, shortName, Type) 
VALUES ('Multi-Agency Contract','MAC','Contract');