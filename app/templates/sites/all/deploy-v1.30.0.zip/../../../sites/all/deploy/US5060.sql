ALTER TABLE `dbSolutionMatrix`.`tbContractSolutions` ADD `published` BOOLEAN NOT NULL ;
UPDATE `dbSolutionMatrix`.`tbContractSolutions` SET published=1;
