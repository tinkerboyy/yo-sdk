ALTER TABLE dbSolutionMatrix.tbContractSolutions ADD COLUMN `servicesProvidedEncoded` mediumtext AFTER servicesProvided;
